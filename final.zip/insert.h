struct Node* insert(struct Node* root, int data);
