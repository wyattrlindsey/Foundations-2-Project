struct Node *search(struct Node *root, int data);
