void test_search_empty_tree(void);
void test_search_one_node_tree(void);
void test_search_multiple_node_tree(void);
